import { NavLink, useLocation } from "react-router-dom";
import Logo from "../ui/Logo";
import "../../styles/components/Sidebar.css";

function Sidebar() {
  const location = useLocation();
  const isOrdersActive = location.pathname.startsWith("/orders");

  return (
    <aside className="admin-sidebar">
      {/* Brand / Logo Section matching Figma */}
      <div className="admin-sidebar__logo">
        <Logo variant="icon-only" width={43} height={51} />
      </div>

      {/* Navigation Links with Interchangeable Colors & SVG Specs */}
      <nav className="admin-sidebar__nav">
        <div className="admin-sidebar__menu">
          {/* 1. Home / Dashboard */}
          <NavLink
            to="/"
            end
            className={({ isActive }) =>
              `admin-sidebar__link ${isActive ? "admin-sidebar__link--active" : ""}`
            }
            title="Dashboard"
          >
            <svg
              width="28"
              height="31"
              viewBox="0 0 28 31"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="admin-sidebar__icon"
            >
              <path
                d="M0 27.125V11.375C0 10.8208 0.12425 10.2958 0.37275 9.8C0.62125 9.30417 0.963667 8.89583 1.4 8.575L11.9 0.7C12.5125 0.233333 13.2125 0 14 0C14.7875 0 15.4875 0.233333 16.1 0.7L26.6 8.575C27.0375 8.89583 27.3805 9.30417 27.629 9.8C27.8775 10.2958 28.0012 10.8208 28 11.375V27.125C28 28.0875 27.657 28.9118 26.971 29.5977C26.285 30.2838 25.4613 30.6262 24.5 30.625H19.25C18.7542 30.625 18.3388 30.457 18.004 30.121C17.6692 29.785 17.5012 29.3697 17.5 28.875V20.125C17.5 19.6292 17.332 19.2138 16.996 18.879C16.66 18.5442 16.2447 18.3762 15.75 18.375H12.25C11.7542 18.375 11.3388 18.543 11.004 18.879C10.6692 19.215 10.5012 19.6303 10.5 20.125V28.875C10.5 29.3708 10.332 29.7867 9.996 30.1227C9.66 30.4587 9.24467 30.6262 8.75 30.625H3.5C2.5375 30.625 1.71383 30.2826 1.029 29.5977C0.344166 28.9129 0.00116667 28.0887 0 27.125Z"
                fill="currentColor"
              />
            </svg>
          </NavLink>

          {/* 2. Orders (Active on /orders and /orders/create) */}
          <NavLink
            to="/orders"
            className={`admin-sidebar__link ${isOrdersActive ? "admin-sidebar__link--active" : ""}`}
            title="Pesanan"
          >
            <svg
              width="27"
              height="33"
              viewBox="0 0 27 33"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="admin-sidebar__icon"
            >
              <path
                d="M19.5 4.58887C21.9076 4.58887 23.1115 4.58887 23.9762 5.10924C24.3506 5.33451 24.672 5.62399 24.9222 5.96113C25.5 6.73992 25.5 7.82406 25.5 9.99234V24.6589C25.5 27.57 25.5 29.0256 24.4958 29.9299C23.4916 30.8343 21.8753 30.8343 18.6429 30.8343H8.35714C5.12465 30.8343 3.50841 30.8343 2.50421 29.9299C1.5 29.0256 1.5 27.57 1.5 24.6589V9.99234C1.5 7.82406 1.5 6.73992 2.07782 5.96113C2.32796 5.62399 2.64939 5.33451 3.02376 5.10924C3.88853 4.58887 5.09235 4.58887 7.5 4.58887"
                stroke="currentColor"
                strokeWidth="3"
              />
              <path
                d="M8.3584 4.5877C8.3584 2.88241 9.89342 1.5 11.787 1.5H15.2155C17.1091 1.5 18.6441 2.88241 18.6441 4.5877C18.6441 6.29299 17.1091 7.67539 15.2155 7.67539H11.787C9.89342 7.67539 8.3584 6.29299 8.3584 4.5877Z"
                stroke="currentColor"
                strokeWidth="3"
              />
              <path
                d="M8.3584 15.3955L18.6441 15.3955"
                stroke="currentColor"
                strokeWidth="3"
                strokeLinecap="round"
              />
              <path
                d="M8.3584 21.5703L15.2155 21.5703"
                stroke="currentColor"
                strokeWidth="3"
                strokeLinecap="round"
              />
            </svg>
          </NavLink>

          {/* 3. Services / Package */}
          <NavLink
            to="/services"
            className={({ isActive }) =>
              `admin-sidebar__link ${isActive ? "admin-sidebar__link--active" : ""}`
            }
            title="Layanan"
          >
            <svg
              width="33"
              height="33"
              viewBox="0 0 33 33"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="admin-sidebar__icon"
            >
              <path
                fillRule="evenodd"
                clipRule="evenodd"
                d="M16.125 0C15.2175 0 14.382 0.225 13.4685 0.603C12.585 0.969 11.559 1.5075 10.2825 2.178L7.1805 3.8055C5.613 4.6275 4.3605 5.286 3.39 5.9325C2.388 6.603 1.614 7.308 1.0515 8.2635C0.4905 9.216 0.2385 10.248 0.117 11.4765C-7.82311e-08 12.669 0 14.1345 0 15.9795V16.2705C0 18.1155 -7.82311e-08 19.581 0.117 20.7735C0.2385 22.0035 0.492 23.034 1.0515 23.9865C1.614 24.942 2.3865 25.647 3.3915 26.3175C4.359 26.964 5.613 27.6225 7.1805 28.4445L10.2825 30.072C11.559 30.7425 12.585 31.281 13.4685 31.647C14.3835 32.025 15.2175 32.25 16.125 32.25C17.0325 32.25 17.868 32.025 18.7815 31.647C19.665 31.281 20.691 30.7425 21.9675 30.072L25.0695 28.446C26.637 27.6225 27.8895 26.964 28.8585 26.3175C29.8635 25.647 30.636 24.942 31.1985 23.9865C31.7595 23.034 32.0115 22.002 32.133 20.7735C32.25 19.581 32.25 18.1155 32.25 16.272V15.978C32.25 14.1345 32.25 12.669 32.133 11.4765C32.0115 10.2465 31.758 9.216 31.1985 8.2635C30.636 7.308 29.8635 6.603 28.8585 5.9325C27.891 5.286 26.637 4.6275 25.0695 3.8055L21.9675 2.178C20.691 1.5075 19.665 0.969 18.7815 0.603C17.8665 0.225 17.0325 0 16.125 0ZM11.28 4.194C12.615 3.4935 13.551 3.0045 14.328 2.6835C15.084 2.37 15.6165 2.25 16.125 2.25C16.635 2.25 17.166 2.37 17.922 2.6835C18.699 3.0045 19.6335 3.4935 20.9685 4.194L23.9685 5.769C25.6035 6.6255 26.751 7.23 27.6105 7.803C28.0335 8.0865 28.365 8.349 28.635 8.613L23.6385 11.1105L10.8885 4.3995L11.28 4.194ZM8.5425 5.631L8.2815 5.769C6.6465 6.6255 5.499 7.23 4.641 7.803C4.27517 8.04072 3.9322 8.31188 3.6165 8.613L16.125 14.868L21.1605 12.348L8.8515 5.871C8.73606 5.80844 8.63168 5.72737 8.5425 5.631ZM2.532 10.5855C2.457 10.9065 2.3985 11.271 2.3565 11.6955C2.2515 12.7665 2.25 14.121 2.25 16.0365V16.212C2.25 18.129 2.25 19.4835 2.3565 20.553C2.46 21.5985 2.6565 22.275 2.991 22.845C3.324 23.4105 3.8055 23.889 4.641 24.447C5.499 25.02 6.6465 25.6245 8.2815 26.481L11.2815 28.056C12.6165 28.7565 13.551 29.2455 14.328 29.5665C14.572 29.6675 14.796 29.75 15 29.814V16.8195L2.532 10.5855ZM17.25 29.8125C17.454 29.7495 17.678 29.6675 17.922 29.5665C18.699 29.2455 19.6335 28.7565 20.9685 28.056L23.9685 26.481C25.6035 25.623 26.751 25.02 27.6105 24.447C28.4445 23.889 28.926 23.4105 29.2605 22.845C29.595 22.275 29.79 21.6 29.8935 20.553C29.9985 19.4835 30 18.129 30 16.2135V16.038C30 14.121 30 12.7665 29.8935 11.697C29.8582 11.3237 29.7996 10.953 29.718 10.587L24.75 13.0695V17.625C24.75 17.9234 24.6315 18.2095 24.4205 18.4205C24.2095 18.6315 23.9234 18.75 23.625 18.75C23.3266 18.75 23.0405 18.6315 22.8295 18.4205C22.6185 18.2095 22.5 17.9234 22.5 17.625V14.196L17.25 16.821V29.8125Z"
                fill="currentColor"
              />
            </svg>
          </NavLink>

          {/* 4. Chat / Messages */}
          <NavLink
            to="/chat"
            className={({ isActive }) =>
              `admin-sidebar__link ${isActive ? "admin-sidebar__link--active" : ""}`
            }
            title="Pesan & Masukan"
          >
            <svg
              width="30"
              height="30"
              viewBox="0 0 30 30"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="admin-sidebar__icon"
            >
              <path
                d="M3 3H27V21H4.755L3 22.755V3ZM3 0C1.35 0 0.015 1.35 0.015 3L0 30L6 24H27C28.65 24 30 22.65 30 21V3C30 1.35 28.65 0 27 0H3ZM6 15H18V18H6V15ZM6 10.5H24V13.5H6V10.5ZM6 6H24V9H6V6Z"
                fill="currentColor"
              />
            </svg>
          </NavLink>
        </div>

        {/* Bottom Actions & User Profile */}
        <div className="admin-sidebar__footer">
          {/* Notification Button with Official Figma Bell SVG */}
          <NavLink
            to="/notifications"
            className={({ isActive }) =>
              `admin-sidebar__icon-btn ${isActive ? "admin-sidebar__icon-btn--active" : ""}`
            }
            title="Notifikasi"
            aria-label="Ke halaman Notifikasi"
          >
            <svg
              width="40"
              height="40"
              viewBox="0 0 40 40"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="admin-sidebar__icon"
            >
              <path
                d="M10.0003 31.666V16.666C10.0003 14.0139 11.0539 11.4703 12.9293 9.59495C14.8046 7.71958 17.3482 6.66602 20.0003 6.66602C22.6525 6.66602 25.196 7.71958 27.0714 9.59495C28.9468 11.4703 30.0003 14.0139 30.0003 16.666V31.666M10.0003 31.666H30.0003M10.0003 31.666H6.66699M30.0003 31.666H33.3337M18.3337 36.666H21.667"
                stroke="currentColor"
                strokeWidth="3.5"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              <path
                d="M20.0007 6.66634C20.9211 6.66634 21.6673 5.92015 21.6673 4.99967C21.6673 4.0792 20.9211 3.33301 20.0007 3.33301C19.0802 3.33301 18.334 4.0792 18.334 4.99967C18.334 5.92015 19.0802 6.66634 20.0007 6.66634Z"
                stroke="currentColor"
                strokeWidth="3.5"
              />
            </svg>
          </NavLink>

          {/* Avatar Profile — click to go to Profile page */}
          <NavLink
            to="/profile"
            className={({ isActive }) =>
              `admin-sidebar__avatar-wrapper ${isActive ? "admin-sidebar__avatar-wrapper--active" : ""}`
            }
            title="Profil Pengguna"
            aria-label="Ke halaman Profile"
          >
            <img
              src="https://api.dicebear.com/7.x/bottts/svg?seed=LaundryAdmin"
              alt="User Avatar"
              className="admin-sidebar__avatar"
            />
          </NavLink>
        </div>
      </nav>
    </aside>
  );
}

export default Sidebar;